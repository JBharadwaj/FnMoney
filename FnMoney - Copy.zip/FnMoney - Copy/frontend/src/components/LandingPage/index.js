// HomePage.js
import React from "react";
import { Link } from "react-router-dom";
import "./index.css";

const LandingPage = () => {
  return (
    <div>
      <div className="landing-page-navbar">
        <Link to="/home" className="nav-link">Home</Link>
        <Link to="/about" className="nav-link">About</Link>
        <Link to="/assessment" className="nav-link">Assessment Form</Link>
        <Link to="/contact" className="nav-link">Contact</Link>
      </div>
      <div className="content">
        <h1>Welcome</h1>
        <p>Go to home page <span className="homePage">Home</span></p>
        <p>This is the main content area of the home page. You can add more text or components here as needed.</p>
      </div>
    </div>
  );
};

export default LandingPage;
