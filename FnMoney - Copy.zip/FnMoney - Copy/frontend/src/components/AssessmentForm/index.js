import React, { useState } from "react";
import "./index.css";
import { useNavigate } from "react-router-dom";

const AssessmentForm = () => {
  const [name, setName] = useState("");
  const [link, setLink] = useState("");
  const [description, setDescription] = useState("");
  const navigate = useNavigate();

  const onSubmitAssessmentForm = async (e) => {
    e.preventDefault();
    try {
      const authorizationCode = localStorage.getItem('auth');
      const email = localStorage.getItem('email');


      let parsedToken = null;
      if (authorizationCode) {
        try {
          parsedToken = JSON.parse(authorizationCode);
        } catch (error) {
          console.error('Error parsing token:', error);
        }
      }

      const formData = {
        email,
        name,
        link,
        description,
      };

      console.log("Submitting form data:", formData);

      const response = await fetch(
        "http://localhost:5000/user/assessment-submit",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${parsedToken.token}`,
          },
          body: JSON.stringify(formData),
        }
      );
      
      if(response.ok) {
        alert("Successfully registered");
        navigate("/home");
        setName("");
        setLink("");
        setDescription("");
      }

    } catch (error) {
      console.error("Error submitting form:", error);
    }
  };

  

  return (
    <div className="details-form-bg-container">
      <div className="details-form-container">
        <h1 className="details-form-heading">Assessment Form</h1>
        <form onSubmit={onSubmitAssessmentForm}>
          <div className="input-container">
            <label className="details-form-label-el" htmlFor="name">
              Assessment Name
            </label>
            <input
              type="text"
              className="details-form-input-el"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              id="name"
              required
            />
          </div>
          <div className="input-container">
            <label className="details-form-label-el" htmlFor="email">
              Link for the assessment
            </label>
            <input
              type="text"
              className="details-form-input-el"
              placeholder="Enter assessment link (if any)"
              value={link}
              onChange={(e) => setLink(e.target.value)}
              id="link"

            />
          </div>
          <div className="input-container">
            <label className="details-form-label-el" htmlFor="description">
              Description
            </label>
            <textarea
              className="details-form-input-el"
              placeholder="Enter a brief description about yourself"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              id="description"
              required
            />
          </div>
          <button
            className="details-form-signup-btn"
            type="submit"
          >
            Submit
          </button>
        </form>
        <div>
            <p className="new-account-page-details-description">
              Back to <span className="span" onClick={()=>navigate('/home')}>Home</span>
            </p>
          </div>
      </div>
    </div>
  );
};

export default AssessmentForm;
