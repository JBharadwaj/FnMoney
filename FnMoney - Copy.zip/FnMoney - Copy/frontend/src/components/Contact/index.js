import React from "react";

const Contact = () => {
  return (
    <div>
      <h1>Contact</h1>
      <p>Get in touch with us using the information provided here.</p>
    </div>
  );
};

export default Contact;
