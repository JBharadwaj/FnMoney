import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";

import "./index.css";

const HomePage = () => {
  const [assessments, setAssessments] = useState([]);

  useEffect(() => {
    // Fetch assessment details when component mounts
    const fetchAssessments = async () => {
      try {
        const response = await fetch('http://localhost:5000/user/assessments');
        const data = await response.json();
        setAssessments(data);
      } catch (error) {
        console.error("Error fetching assessments:", error);
      }
    };

    fetchAssessments();
  }, []);

  return (
    <>
      <div className="navbar">
        <Link to="/assessment" className="nav-link">Assessment</Link>
        <Link to="/contact" className="nav-link">Contact</Link>
      </div>

      <div className="content">
        <h1>Assessment Details</h1>
        <div className="assessment-list">
          {assessments.length > 0 ? (
            assessments.map((assessment, index) => (
              <div key={index} className="assessment-item">
                <h2>{assessment.name}</h2>
                <p>{assessment.description}</p>
                <button>Get Started</button>
              </div>
            ))
          ) : (
            <p>No assessments available.</p>
          )}
        </div>
      </div>
    </>
  );
};

export default HomePage;
