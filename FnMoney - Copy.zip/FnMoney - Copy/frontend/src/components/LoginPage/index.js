import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./index.css";
import { IoEye, IoEyeOff } from "react-icons/io5";

const LoginPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [passwordHidden, setPasswordHidden] = useState(true);
  const [passwordError, setPasswordError] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const navigate = useNavigate();

  const passwordType = passwordHidden ? "password" : "text";

  const passwordIcon = passwordHidden ? (
    <IoEye size={26} onClick={() => setPasswordHidden(!passwordHidden)} />
  ) : (
    <IoEyeOff size={26} onClick={() => setPasswordHidden(!passwordHidden)} />
  );

  const onClickSignIn = async (email, password) => {
    localStorage.setItem("email", email);
    try {
      const response = await fetch("http://localhost:5000/user/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });
      console.log(response);
      const data = await response.json();
      console.log(data);
      localStorage.setItem("customerId", data.id);
      localStorage.setItem("customerToken", data.token);
      if (response.status === 200) {
        // have to redirect to the user homepage
        navigate("/landing");
      } else {
        setPasswordError(true);
        setErrorMsg(data.error);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <div className="login-page-bg-container">
      <div className="login-page-main-container">
        <div className="login-page-details-bg-container">
          <div className="login-page-details-main-container">
            <h1 className="login-page-details-heading">Welcome Back!</h1>
            <div className="input-container">
              <label className="login-page-details-label-el" htmlFor="email">
                Email
              </label>
              <input
                type="email"
                className="login-page-details-input-el"
                placeholder="johndoe@email.net"
                id="email"
                onChange={(e) => setEmail(e.target.value)}
                value={email}
              />
            </div>
            <div className="input-container">
              <label className="login-page-details-label-el" htmlFor="password">
                Password
              </label>
              <div className="password-container">
                <input
                  type={passwordType}
                  className="password-input"
                  placeholder="********"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  id="password"
                />
              </div>
            </div>
            <button
              className="login-page-details-proceed-btn"
              type="button"
              onClick={() => onClickSignIn(email, password)}
            >
              Sign in
            </button>
            {passwordError && <p className="error-msg">{errorMsg}</p>}
            <p
              className="forgot-password-description"
              onClick={() => navigate("/reset-password")}
            >
              Forgot Password?
            </p>
          </div>
          <div>
            <p className="login-page-details-description">
              Don't have an account?{" "}
              <span className="span" onClick={() => navigate("/register")}>
                Register
              </span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
