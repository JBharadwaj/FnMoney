import React, { useState } from "react";
import "./index.css";
import { useNavigate } from "react-router-dom";

const RegistrationForm = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [contact, setContact] = useState("");
  const [description, setDescription] = useState("");
  const [password,setPassword]=useState(" ");
  const navigate = useNavigate();
  const [check, setChecked] = useState(false);

  const onSubmitRegistrationForm = async (e) => {
    e.preventDefault();
  
    // Prepare form data
    const formData = {
      name,
      email,
      contact,
      description,
      password,
    };
  
    try {
      const response = await fetch("http://localhost:5000/user/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });
  
      if (response.ok) {
        alert("Successfully registered");
        navigate("/login");
        // Clear input fields
        setName("");
        setEmail("");
        setContact("");
        setDescription("");
        setPassword("");
        setChecked(false);
      } else {
        // Handle server-side errors
        const errorData = await response.json();
        console.error("Failed to register:", errorData);
        alert(`Registration failed: ${errorData.message || 'Unknown error'}`);
      }
    } catch (error) {
      // Handle network or unexpected errors
      console.error("Error submitting form:", error);
      alert('An error occurred while registering');
    }
  };
  

  const readMore =
    "By providing your information for the registration process, you consent to Syntropy collecting, using, and disclosing this information solely for the purpose of offering you consultation services tailored to your needs and demographics. Your information will be treated confidentially and will not be used for any marketing, professional, or other purposes.";
  const readLess =
    "By providing your information for the registration process, you consent to Syntropy collecting, using, and ";
  const [readMoreToggle, setReadMoreToggle] = useState(true);
  const readBtnTxt = readMoreToggle ? "ReadMore" : "ReadLess";
  const readConsentMsg = readMoreToggle ? readLess : readMore;

  return (
    <div className="details-form-bg-container">
      <div className="details-form-container">
        <h1 className="details-form-heading">Registration Form</h1>
        <form onSubmit={onSubmitRegistrationForm}>
          <div className="input-container">
            <label className="details-form-label-el" htmlFor="name">
              Name
            </label>
            <input
              type="text"
              className="details-form-input-el"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              id="name"
              required
            />
          </div>
          <div className="input-container">
            <label className="details-form-label-el" htmlFor="email">
              Email
            </label>
            <input
              type="email"
              className="details-form-input-el"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              id="email"
              required
            />
          </div>
          <div className="input-container">
            <label className="details-form-label-el" htmlFor="name">
              Password
            </label>
            <input
              type="text"
              className="details-form-input-el"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              id="password"
              required
            />
          </div>
          <div className="input-container">
            <label className="details-form-label-el" htmlFor="contact">
              Contact
            </label>
            <input
              type="tel"
              pattern="[0-9]{10}"
              className="details-form-input-el"
              placeholder="Enter your contact number"
              value={contact}
              onChange={(e) => setContact(e.target.value)}
              id="contact"
              required
            />
          </div>
          <div className="input-container">
            <label className="details-form-label-el" htmlFor="description">
              Description
            </label>
            <textarea
              className="details-form-input-el"
              placeholder="Enter a brief description about yourself"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              id="description"
              required
            />
          </div>
          <div className="details-form-checkbox-container">
            <input
              type="checkbox"
              className="details-form-checkbox"
              onChange={(e) => setChecked(!check)}
              value={check}
            />
            <p className="details-form-consent-description">
              {`"${readConsentMsg} `}{" "}
              <span
                className="details-form-readmor-span"
                onClick={() => setReadMoreToggle(!readMoreToggle)}
              >{`${readBtnTxt}`}</span>
              "
            </p>
          </div>
          <button
            className="details-form-signup-btn"
            type="submit"
            disabled={!check}
          >
            Signup
          </button>
        </form>
        <div>
            <p className="new-account-page-details-description">
              Don't have an account? <span className="span" onClick={()=>navigate('/login')}>Login</span>
            </p>
          </div>
      </div>
    </div>
  );
};

export default RegistrationForm;
