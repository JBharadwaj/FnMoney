import React from 'react';
import { BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import RegistrationForm from './components/RegistrationForm';
import LoginPage from './components/LoginPage';
import AssessmentForm from './components/AssessmentForm';
import HomePage from './components/HomePage';
import LandingPage from './components/LandingPage';
import Contact from './components/Contact';
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/landing" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage/>}/>
        <Route path="/assessment" element={<AssessmentForm/>}/>
        <Route path="/contact" element={<Contact/>}/>
        <Route path="/home" element={<HomePage/>}/>
        <Route path="/" element={<RegistrationForm/>}/>
      </Routes>
    </Router>
  );
}


export default App;
