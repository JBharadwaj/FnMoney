const mongoose = require('mongoose');

const assessmentSchema = new mongoose.Schema({
    name:{
        type:String,
        required:true,
    },
  email: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  link: {
    type: String,
    required: false
  }
});

const Assessment = mongoose.model('Assessment', assessmentSchema);

module.exports = Assessment;
