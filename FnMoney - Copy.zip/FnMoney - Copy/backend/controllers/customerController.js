const User = require("../models/userschema");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const dotenv = require("dotenv");
const Assessment=require("../models/assessmentschema");

dotenv.config({ path: "./config.env" });


exports.login = async (req, res) => {
    const { email, password } = req.body;
    try {
      const customer = await User.findOne({ email });
      const _id = { customer };
      if (!customer) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
      if (!customer.password) {
        return res.status(401).json({ error: "Password details not found" });
      }
  
      const storedPassword = customer.password;
  
      const isMatch = await bcrypt.compare(password, storedPassword);
  
      if (!isMatch) {
        return res.status(401).json({ error: "Invalid email or password" });
      } else {
        const loginToken = jwt.sign({ email, _id }, "FnMoney", {
          expiresIn: "1h",
        });
        res.status(200).json({
          message: "Login successful",
          token: loginToken,
          id: customer._id,
        });
      }
    } catch (error) {
      console.error("Error during login:", error.message);
      res.status(500).json({ error: "Server error" });
    }
};

exports.registerCustomer = async (req, res) => {
    try {
      const { name, email, contact, description, password } = req.body;
  
      // Check if all required fields are provided
      if (!name || !email || !contact || !description || !password) {
        return res.status(400).send("All fields are required");
      }
  
      // Check if user already exists
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).send("User with provided email already exists");
      }
  
      // Hash the password
      const hashedPassword = await bcrypt.hash(password, 10);
  
      // Create new user
      const newUser = new User({
        name,
        email,
        contact,
        description,
        password: hashedPassword, // Store hashed password
      });
  
      // Save the user to the database
      await newUser.save();
  
      res.status(200).json({ message: "Success" });
    } catch (error) {
      console.error("Error registering customer:", error.message);
      res.status(500).send("An error occurred while registering the customer");
    }
  };
  exports.assessmentSubmit = async (req, res) => {
    try {
      const { email,name,link,description } = req.body;
      
      // Create a new user instance
      const newAssessment = new Assessment({
        name,
        email,
        link,
        description, 
      });
  
      // Save the user to the database
      await newAssessment.save();
      res.status(200).json({ message: "Success" });
    } catch (error) {
      console.error("Error :", error.message);
      res.status(500).send("An error occurred while submitting the assessment");
    }
  };
  

  exports.getAssessments = async (req, res) => {
    try {
      // Fetch all assessments from the database
      const assessments = await Assessment.find();
  
      // Respond with the fetched assessments
      res.status(200).json(assessments);
    } catch (error) {
      console.error("Error fetching assessments:", error.message);
      res.status(500).send("An error occurred while fetching assessments");
    }
  };
  