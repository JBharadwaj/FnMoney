const express = require("express");
const router = express.Router();
// const paymentController = require("../controllers/paymentController");
const customerController = require("../controllers/customerController.js");
router.post("/login", customerController.login);
router.post("/register", customerController.registerCustomer);
router.post("/assessment-submit",customerController.assessmentSubmit);
router.get("/assessments",customerController.getAssessments);

module.exports = router;
