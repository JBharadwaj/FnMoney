const express = require("express");
const morgan = require("morgan");
const bodyParser = require("body-parser");
const session = require("express-session");
const cors = require("cors");
const path=require("path");
const cookieParser = require("cookie-parser");
const customerRoutes = require("./routes/customerRoutes");

const app = express();
const http = require("http");
const server = http.createServer(app); // Create HTTP server

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname,'public')));
app.use(
    cors({
        origin: "http://localhost:3000", // Specify your client app's origin
    })
);
app.use(
    session({
        secret: "secret",
        resave: false,
        saveUninitialized: false,
    })
);


app.use("/user", customerRoutes);


module.exports = app;
